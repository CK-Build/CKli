# Remotes
This folder contains the `Remotes.zip` that is committed. It is unzipped automatically locally
and the `.gitignore` prevents the extracted folders to be committed.

Each root folder contains a Stack and one or more repositories that are used by unit tests.
