﻿namespace CodeCakeBuilder
{
    public class Class1
    {

    }
}
