﻿namespace SomeProject
{
    public class Class1
    {

    }
}
