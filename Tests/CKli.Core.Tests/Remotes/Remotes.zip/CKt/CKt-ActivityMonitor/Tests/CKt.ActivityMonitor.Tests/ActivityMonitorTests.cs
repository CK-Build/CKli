using NUnit.Framework;
using Shouldly;

namespace CKt.Core.Monitoring.Tests;

[TestFixture]
public class ActivityMonitorTests
{
    [Test]
    public void simple_test()
    {
        ActivityMonitor monitor = new ActivityMonitor();
        monitor.ShouldNotBeNull();
    }
}
