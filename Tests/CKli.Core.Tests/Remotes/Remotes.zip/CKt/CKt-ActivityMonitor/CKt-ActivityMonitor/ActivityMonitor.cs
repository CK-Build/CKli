using System;

namespace CKt.Core;

public class ActivityMonitor
{
    public void Info( string message ) => Console.WriteLine( message );
}
